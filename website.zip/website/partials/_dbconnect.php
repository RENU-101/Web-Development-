<?php
//script to connect to the database
$servername = "localhost";
$username = "root";
$password = "strenu101";
$database = "idiscuss";
$conn = mysqli_connect($servername, $username, $password, $database);
?>